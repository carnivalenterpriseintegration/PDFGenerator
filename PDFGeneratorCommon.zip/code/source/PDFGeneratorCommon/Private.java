package PDFGeneratorCommon;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import com.itextpdf.kernel.utils.PdfMerger;
import com.itextpdf.html2pdf.*;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.layout.Document;
// --- <<IS-END-IMPORTS>> ---

public final class Private

{
	// ---( internal utility methods )---

	final static Private _instance = new Private();

	static Private _newInstance() { return new Private(); }

	static Private _cast(Object o) { return (Private)o; }

	// ---( server methods )---




	public static final void convertHtmlToPdfFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertHtmlToPdfFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required htmlString
		// [i] field:0:required fullPDFFileName
		// pipeline
			try{
				IDataCursor pipelineCursor = pipeline.getCursor();
				String	htmlString = IDataUtil.getString( pipelineCursor, "htmlString" );
				String	out = IDataUtil.getString( pipelineCursor, "fullPDFFileName" );
				//File htmlFile = new File(htmlString);
				PdfDocument pdfDocument = new PdfDocument(new PdfWriter(out));
				// use this line to set the page size
				pdfDocument.setDefaultPageSize(PageSize.LEGAL);
				Document document = HtmlConverter.convertToDocument(htmlString, pdfDocument, new ConverterProperties());
				document.close();
				pipelineCursor.destroy();
				}catch(IOException ioe) {
				    System.err.println("Caught IOException: " + ioe.getMessage());}
			
			
		
		// pipeline 
			//try{
			//HtmlConverter.convertToPdf(htmlString, new FileOutputStream(dest));
			//}catch(IOException ioe) {
			   // System.err.println("Caught IOException: " + ioe.getMessage());}
			
		// --- <<IS-END>> ---

                
	}



	public static final void mergerPDFFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mergerPDFFiles)>> ---
		// @sigtype java 3.5
		// [i] field:1:required fileList
		// [i] field:0:required masterFileName
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	fileList = IDataUtil.getStringArray( pipelineCursor, "fileList" );
			String	masterFileName = IDataUtil.getString( pipelineCursor, "masterFileName" );
			pipelineCursor.destroy();
			// pipeline
			try{	
			PdfWriter writer = new PdfWriter(masterFileName);
			PdfDocument pdf = new PdfDocument(writer);
			PdfMerger merger = new PdfMerger(pdf);
			for (String file : fileList) {
				PdfDocument temp = new PdfDocument(new PdfReader(file));
				merger.merge(temp, 1, temp.getNumberOfPages());
				temp.close();
			    }
			pdf.close();
			}catch(IOException ioe) {
			    System.err.println("Caught IOException: " + ioe.getMessage());}
		// --- <<IS-END>> ---

                
	}
}

